<template>
  <div>
    <el-button @click="search" type="primary">查询</el-button>
  </div>
</template>

<script>
  export default{

  }
</script>

<style scoped></style>
